var http = require('http');
var server = http.createServer(function(req, res) {
  res.end('<html><body>Site da Fatec Sorocaba</body></html>');
});

const porta = 3000;
server.listen(porta);
console.log(`Acesse http://localhost:${porta}`);
